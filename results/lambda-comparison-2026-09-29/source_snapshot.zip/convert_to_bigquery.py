"""
Converts your per-cascade JSON files (one file per tweet id, like
A0bSW2Rem.json) into a SINGLE newline-delimited JSON (.jsonl / NDJSON)
file -- the format BigQuery's JSON loader expects: one JSON object per
line, not one file per record and not a JSON array wrapping everything.

BigQuery handles the nested structure natively: the `comment` array
becomes a REPEATED RECORD column, and `centrality` becomes a nested
RECORD column, automatically, via schema auto-detection. No flattening
needed -- you'll be able to expand/browse the nested comment rows
right in the BigQuery preview, similar to how a normal table row
looks, just with an expandable nested field.

Run with:  python convert_to_bigquery.py

Output: weibo_data.jsonl in the current directory -- upload THIS one
file to BigQuery (see the steps printed at the end).
"""
import json
from pathlib import Path

INPUT_DIR = "/storage/weibo1"   # <-- change to wherever your JSON files are
OUTPUT_FILE = "weibo_data.jsonl"


def main():
    input_path = Path(INPUT_DIR)
    files = sorted(input_path.glob("*.json"))
    if not files:
        raise FileNotFoundError(f"No .json files found in {INPUT_DIR}")

    print(f"Found {len(files)} files in {INPUT_DIR}")

    written = 0
    skipped = 0
    with open(OUTPUT_FILE, "w", encoding="utf-8") as out:
        for fpath in files:
            try:
                with open(fpath, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except (json.JSONDecodeError, UnicodeDecodeError) as e:
                print(f"  Skipping {fpath.name}: {e}")
                skipped += 1
                continue

            # Tag each row with which file it came from -- useful once
            # this is in BigQuery and you want to trace a row back to
            # its source file.
            data["_source_file"] = fpath.name

            # One JSON object per line -- this is what makes it NDJSON.
            out.write(json.dumps(data, ensure_ascii=False) + "\n")
            written += 1

    print(f"\nWrote {written} rows to {OUTPUT_FILE} ({skipped} skipped)")
    print(f"\n=== Next steps: loading {OUTPUT_FILE} into BigQuery ===")
    print("""
1. Go to console.cloud.google.com/bigquery and select (or create) your project.
2. In the Explorer panel, click your project -> find or create a dataset
   (e.g. right-click your project -> "Create dataset").
3. Inside that dataset, click "Create table".
4. Under "Source", choose "Upload", then select weibo_data.jsonl from
   this machine (or upload it to a Google Cloud Storage bucket first
   and select "Google Cloud Storage" as the source, if the file is
   large -- BigQuery's direct-upload has a size limit, GCS does not).
5. Set "File format" to "JSONL (Newline delimited JSON)".
6. Give the table a name (e.g. "cascades").
7. Under "Schema", leave "Auto detect" checked -- BigQuery will infer
   the nested structure (comment as REPEATED RECORD, centrality as
   RECORD) directly from the file.
8. Click "Create table".
9. Once it's created, click the table and open the "Preview" tab --
   that's the same view as your Research-Heart-Failure screenshot,
   now showing your cascade data. Nested fields (comment, centrality)
   show as expandable/collapsible in the preview.
""")


if __name__ == "__main__":
    main()
